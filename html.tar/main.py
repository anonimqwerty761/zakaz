from flask import Flask, render_template, request, redirect, url_for, jsonify
import jwt
import datetime

app = Flask(__name__)
app.secret_key = '1290881177'  # Замените на свой секретный ключ

# Простой хранилище пользователей для примера
users = {
    "admin": "admin"
}


def generate_jwt(username):
    token = jwt.encode({
        'username': username,
        'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=1)
    }, app.secret_key)
    return token


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/login', methods=['POST', "GET"])
def login():
    if request.method == "GET":
        if request.args.get("lang") == "ru":
            return render_template('login_ru.html')
        elif request.args.get("lang") == "en":
            return render_template('login_en.html')
    elif request.method == "POST":
        username = request.form['username']
        password = request.form['password']

        if username in users and users[username] == password:
            token = generate_jwt(username)
            return redirect(url_for('main', token=token))

        return "Неверные учетные данные", 401


@app.route('/register', methods=['POST', "GET"])
def register():
    if request.method == "GET":
        if request.args.get("lang") == "ru":
            return render_template('register_ru.html')
        elif request.args.get("lang") == "en":
            return render_template('register_en.html')
    elif request.method == "POST":
        username = request.form['username']
        password = request.form['password']

        if username not in users:
            users[username] = password
            return "Регистрация успешна", 200

        return "Пользователь уже существует", 400


@app.route('/main')
def main():
    token = request.args.get('token')
    if not token:
        return redirect(url_for('index'))

    try:
        jwt.decode(token, app.secret_key, algorithms=["HS256"])
        return render_template('main.html')
    except jwt.ExpiredSignatureError:
        return "Токен истек", 401
    except jwt.InvalidTokenError:
        return "Недействительный токен", 401


if __name__ == '__main__':
    app.run(debug=True)
